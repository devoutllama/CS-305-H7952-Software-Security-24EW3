package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
//Marks this class as a controller to handle HTTP requests
@RestController
class ServerController {
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray(); // Used for converting bytes to hex

 // This method takes a string input, hashes it using SHA-256, and returns the hex representation of the hash
	private String getHash(String input) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256"); // Creates a MessageDigest for SHA-256
			byte[] messageDigestMD5 = messageDigest.digest(input.getBytes()); // Calculates the digest (hash) of the input string
			return bytesToHex(messageDigestMD5); // Converts the byte array of the hash to a hex string
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace(); // Prints the stack trace if the algorithm is not available
		}
		return input; // Returns the input if there was an error, though you might want to handle this differently
	}

 // Converts a byte array to a hex string
	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2]; // Creates an array of characters
		for (int j = 0; j < bytes.length; j++) {
			int v = bytes[j] & 0xFF; // Makes the byte positive
			hexChars[j * 2] = HEX_ARRAY[v >>> 4]; // Extracts the high nibble
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F]; // Extracts the low nibble
		}
		return new String(hexChars); // Returns the hex string
	}

 // Maps this method to handle HTTP GET requests on the "/hash" path
	@RequestMapping("/hash")
	public String myHash() {
		String data = "Hello Ugochuku Enyi Ebere!"; // The data to be hashed
		String hash = getHash(data); // Gets the hash of the data
		return "<p>data: " + data + "</p><p> Name of Cipher Used: SHA-256 Value: " + hash + "</p>"; // Returns a simple HTML paragraph with the data and its hash
	}
}